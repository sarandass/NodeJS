const fs = require("fs")

fs.mkdirSync("data")

fs.writeFileSync("./data/temp.txt", "welcome to your life", "utf-8")

console.log("creating file done");