const EventEmitter = require("events").EventEmitter

let ee = new EventEmitter()

function onlineEventCallBack() {
    console.log("onlineEvent happened");
}

ee.addListener("onlineEvent", onlineEventCallBack)

// ee.emit("onlineEvent")

// setTimeout(function(){
//     ee.emit("onlineEvent")
// }, 2000)

setInterval(function(){
    ee.emit("onlineEvent")
}, 2000)