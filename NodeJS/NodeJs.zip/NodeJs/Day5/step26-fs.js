const fs = require("fs")

fs.writeFile("temp.txt", "Welcome to your life", "utf-8", function(error){
    if(error){
        console.log("Error ", error);
    }else{
        console.log("file created");
    }
})

// let data = fs.readFileSync("temp.txt", "utf-8")

fs.readFile("temp.txt", "utf-8", function(error, data){
    if(error){
        console.log("Error ", error);
    }else{
        // console.log(data);
        let existingData = data
        fs.writeFileSync("temp.txt", existingData + "\nthere is no turn back", "utf-8")
        console.log("file is updated");
        console.log(fs.statSync("temp.txt").birthtime);
        console.log(fs.statSync("temp.txt").size, "Bytes");
    }
})
