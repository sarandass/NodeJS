const EventEmitter = require("events").EventEmitter;

let ee = new EventEmitter();

ee.on("onlineEvent", function(){
    console.log("onlineEvent Happened log from line 6");
});

/* setTimeout(function(){
    ee.emit("onlineEvent");
},100); */

/* setImmediate(function(){
    ee.emit("onlineEvent");
});
 */

process.nextTick(function(){
    ee.emit("onlineEvent");
});

console.log("log from line 22");