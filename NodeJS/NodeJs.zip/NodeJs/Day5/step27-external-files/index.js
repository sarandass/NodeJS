const fetch = require("fetch")

fetch.fetchUrl("http://www.arcstellar.com/index.html", function(error, meta, data) {
    if(error){
        console.log("Error ", error);
    }else{
        console.log(data.toString());
    }
})