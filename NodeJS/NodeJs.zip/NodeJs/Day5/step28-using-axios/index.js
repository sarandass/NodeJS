const axios = require("axios")
const fs = require("fs")
const path = require("path")

axios
.get("https://www.arcstellar.com/index.html")
.then((res) => {
    let location = path.join("harvest", "index.html")
    fs.writeFileSync(location,res,data, "utf-8")
    console.log("file created");
})
.catch((error) => console.log("Error ", error) )
