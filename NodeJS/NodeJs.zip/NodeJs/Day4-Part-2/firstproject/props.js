let user = "saran"

export {user}