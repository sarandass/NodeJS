let modobj1 = require("../secondproject")
let modobj2 = require("../thirdproject")
let os = require("os")
/*import {user} from "./props.js"

console.log(user);*/
console.log(modobj1);
console.log(modobj2);
console.log(os.arch());
console.log(os.cpus().length);
console.log(os.cpus()[0]);
console.log(os.homedir());
console.log(os.freemem());
console.log(os.totalmem());
