module.exports = {
    title: "welcome to your life"
}