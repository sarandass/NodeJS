require("./step20-custom-global.js")

console.log("Author ", global.author);
console.log("Company", global.company);