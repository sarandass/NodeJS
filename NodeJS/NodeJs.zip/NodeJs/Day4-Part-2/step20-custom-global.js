global.author="Saran"
global.company="Stark"