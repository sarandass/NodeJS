let modobj = require("./step18-module")

console.log(modobj.hero);
console.log(modobj.fname);
console.log(modobj.lname);
