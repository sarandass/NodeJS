var user = "saran"
console.log("user name is: ", user);

for (let i = 0; i < 10; i++){
    console.log(user);
}