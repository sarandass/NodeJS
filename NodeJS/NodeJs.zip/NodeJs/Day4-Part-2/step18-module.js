let hero = "Ironman"
let fname = "Tony"
let lname = "Stark"

// module.exports.hero = hero
// module.exports.fname= fname
// module.exports.lname = lname

module.exports = {
    hero: hero,
    fname: fname,
    lname: lname
}